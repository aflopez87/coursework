/** Shows the user information about the game and allows them to restart */
export default function GameEnd() {
  // TODO: tell the user the final guess and how many tries it took

  // TODO: restart the game when user clicks the button

  return (
    <>
      <h1>🎉 Yay 🎉</h1>
      <form>
        <button>Play again?</button>
      </form>
    </>
  );
}
